#!/usr/bin/env bash
set -euo pipefail

PATCH_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="${1:-}"

find_root() {
  local start="$1"
  local d
  for d in "$start" "$start/.." "$start/../.." "$start/../../.."; do
    if [[ -d "$d/app" && -d "$d/scripts" && -d "$d/site-react" ]]; then
      (cd "$d" && pwd)
      return 0
    fi
  done
  return 1
}

if [[ -z "$PROJECT_ROOT" ]]; then
  if PROJECT_ROOT=$(find_root "$(pwd)"); then
    :
  else
    echo "ERROR: Could not auto-detect project root (needs app/, scripts/, site-react/)" >&2
    echo "Usage: $0 /absolute/path/to/project-root" >&2
    exit 1
  fi
fi

if [[ ! -d "$PROJECT_ROOT/app" || ! -d "$PROJECT_ROOT/scripts" || ! -d "$PROJECT_ROOT/site-react" ]]; then
  echo "ERROR: PROJECT_ROOT does not look like a project root: $PROJECT_ROOT" >&2
  echo "       Expected app/, scripts/, site-react/ under it." >&2
  exit 1
fi

TS=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="$PROJECT_ROOT/.backup_timing_v1_$TS"
mkdir -p "$BACKUP_DIR"

backup_file() {
  local rel="$1"
  if [[ -f "$PROJECT_ROOT/$rel" ]]; then
    mkdir -p "$BACKUP_DIR/$(dirname "$rel")"
    cp -a "$PROJECT_ROOT/$rel" "$BACKUP_DIR/$rel"
  fi
}

backup_file "app/exporter.py"
backup_file "scripts/run_daily.py"
backup_file "site-react/src/types/index.ts"
backup_file "site-react/src/hooks/useWarRoomData.ts"
backup_file "site-react/src/App.tsx"

# Apply patch
cp -a "$PATCH_DIR/update_patch/." "$PROJECT_ROOT/"

echo "Patch applied. Backup saved to: $BACKUP_DIR"

# Quick sanity checks (non-fatal)
python3 -m py_compile "$PROJECT_ROOT/app/timing_v1.py" 2>/dev/null || true
python3 -m py_compile "$PROJECT_ROOT/app/exporter.py" 2>/dev/null || true
python3 -m py_compile "$PROJECT_ROOT/scripts/run_daily.py" 2>/dev/null || true

echo "Next steps:"
echo "  1) Generate CSV: python3 $PROJECT_ROOT/scripts/run_daily.py --window-days 30"
echo "  2) Rebuild frontend: cd $PROJECT_ROOT/site-react && npm install && npm run build"
