# Timing v1 Patch ("When" engine)

This patch adds a new **Timing v1** engine that estimates **when** Crisis (DEFCON enter) and Euphoria/Overheat (rule enter) are likely to **begin**, expressed as:

- cumulative probabilities: **P(event begins within X)**
- **median ETA** date (approx.)
- **mode window** (most likely time window)

## New output
- `data/timing_v1_daily.csv`

## Backend changes
- `app/timing_v1.py` (new)
- `app/exporter.py` adds `export_timing_v1_csv()`
- `scripts/run_daily.py` calls `export_timing_v1_csv(conn)`

## Frontend changes
- Loads `/data/timing_v1_daily.csv`
- Adds a "Timing (When)" section above the Forecast chart

## How it works (v1)
- Features: cycle-like z/slope/vol features from the same raw series used by `forecast_v1`.
- Events:
  - Crisis enter: first day `state in {DEFCON2, DEFCON1}` after not being in crisis.
  - Euphoria enter: first day the euphoria rule flips from 0->1.
- Models: cumulative logistic models per horizon (minimal deps, IRLS), then enforce monotonicity.

## Notes
- Very long horizons (5y/10y) may show `WARMUP`/`NO_FEATURES` if there isn't enough history.
- For Euphoria we apply stronger regularization and temperature scaling to avoid 0/1 saturation.
